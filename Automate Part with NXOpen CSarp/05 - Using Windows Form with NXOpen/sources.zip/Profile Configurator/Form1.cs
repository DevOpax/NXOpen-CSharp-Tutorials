﻿using NXOpen;
using NXOpen.Features.AECDesign;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Profile_Configurator
{
    public partial class Form1 : Form
    {
        private static Session theSession = Session.GetSession();
        private static Part theWorkPart = null;

        private Boolean isNewPart = false;

        //Change this as you needs
        private readonly string template = "D:\\NX_Data\\templates\\L_Profile_Base.prt";
        private readonly string workdir = "D:\\NX_Data\\";


        Dictionary<string, string> defValues = new Dictionary<string, string>
        {
            { "a", "60"},
            { "b" , "80" },
            { "S" , "5" },
            { "angle", "90" },
            { "L", "200" }
        };

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            theWorkPart = theSession.Parts.Work;

            if (theWorkPart != null)
            {

                try
                {
                    NXObject.AttributeInformation attribut = theWorkPart.GetUserAttribute("Type", NXObject.AttributeType.String, -1);
                    NXObject.AttributeInformation attribut2 = theWorkPart.GetUserAttribute("Template", NXObject.AttributeType.Boolean, -1);

                    if (attribut.StringValue != "Profile_L")
                    {
                        isNewPart = true;
                    }

                    if (attribut2.BooleanValue == true)
                    {
                        MessageBox.Show("You try to modify the template, it is not allowed.","Info",MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        isNewPart = true;
                    }
                }
                catch
                {
                    isNewPart = true;
                }
                
   
            }
            else
            {
                isNewPart = true;
            }

            if(isNewPart)
            {
                Set_DefaultValues();
                buttonCreate.Text = "Create";
            }
            else
            {
                Get_Values();
                buttonCreate.Text = "Modify";
            }

        }

        private void Set_DefaultValues()
        {
            foreach(Control ctrl in this.Controls)
            {
                if(ctrl is TextBox && ctrl.Tag != null)
                {
                    string Tag = ctrl.Tag.ToString();
                     ctrl.Text = defValues[Tag];
                }
            }
        }

        private void Get_Values()
        {
            ExpressionCollection collection = theWorkPart.Expressions;

            foreach (Control ctrl in this.Controls)
            {
                if (ctrl is TextBox && ctrl.Tag != null)
                {
                    string Tag = ctrl.Tag.ToString();
                    Expression exp = collection.FindObject(Tag);
                    ctrl.Text = exp.Value.ToString();
                }
            }

        }

        private bool FieldsAreNumeric()
        {
            string message = string.Empty;

            foreach (Control ctrl in this.Controls)
            {
                if (ctrl is TextBox && ctrl.Tag != null)
                {
                    double value;
                    if(double.TryParse(ctrl.Text, out value))
                    {
                        if(value > 0)
                        {
                            continue;
                        }
                        else
                        {
                            message += "The expression " + ctrl.Tag.ToString() + " must be greater than 0." + Environment.NewLine;
                        }
                    }
                    else
                    {
                        message += "The expression " + ctrl.Tag.ToString() + " must be numeric." + Environment.NewLine;
                    }

                }
            }

            if (!string.IsNullOrEmpty(message))
            {
                MessageBox.Show(message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            else
            {
                return true;
            }
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            this.Close();
            //Application.Exit();
        }

        private void buttonCreate_Click(object sender, EventArgs e)
        {
            if (!FieldsAreNumeric())
            {
                return;
            }
            

            if (isNewPart)
            {
                string newname = "L_Profile_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".prt";

                if (File.Exists(workdir + newname))
                {
                    DialogResult res = MessageBox.Show("File already exist, do you want to overwrite it ?","Question",MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (res == DialogResult.No)
                    {
                        return;
                    }
                }

                File.Copy(template,workdir + newname, true);

                if(File.Exists(workdir + newname))
                {
                    PartLoadStatus loadStatus, loadStatus2;
                    BasePart newPart = theSession.Parts.OpenActiveDisplay(workdir + newname, DisplayPartOption.AllowAdditional, out loadStatus);
                    theSession.Parts.SetActiveDisplay(newPart, DisplayPartOption.AllowAdditional, PartDisplayPartWorkPartOption.UseLast, out loadStatus2);

                    loadStatus.Dispose();
                    loadStatus2.Dispose();

                    theWorkPart = theSession.Parts.Work;

                    theWorkPart.SetBooleanUserAttribute("Template", -1, false, NXOpen.Update.Option.Now);

                }
               
            }

            foreach (Control ctrl in this.Controls)
            {
                if (ctrl is TextBox && ctrl.Tag != null)
                {
                    string Tag = ctrl.Tag.ToString();
                    string value = ctrl.Text;
                    Expression exp = theWorkPart.Expressions.FindObject(Tag);
                    theWorkPart.Expressions.EditExpression(exp, value);
                }
            }

            theWorkPart.Expressions.UpdateForExternalChange();
            this.Close();

        }

        public static int GetUnloadOption(string arg)
        {
            //Unloads the image explicitly, via an unload dialog
            //return System.Convert.ToInt32(Session.LibraryUnloadOption.Explicitly);

            //Unloads the image immediately after execution within NX
            return System.Convert.ToInt32(Session.LibraryUnloadOption.Immediately);

            //Unloads the image when the NX session terminates
            // return System.Convert.ToInt32(Session.LibraryUnloadOption.AtTermination);
        }

       
    }
}
